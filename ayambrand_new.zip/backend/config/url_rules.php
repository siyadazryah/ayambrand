<?php

return [
//    'admin-post' => 'admin/admin-post/index',
//    'admin-user' => 'admin/admin-user/index',
    'forgot-password' => 'site/forgot',
];
